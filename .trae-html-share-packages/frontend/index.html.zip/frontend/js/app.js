/* ==========================================================================
   LandricsVilla - App init, router, auth guard, global state, shared shell
   Vanilla hash-based router. Loads page HTML fragments into #app-view.
   ========================================================================== */
(function (global) {
  "use strict";

  const PAGES = {
    home: "pages/home/index.html",
    chat: "pages/chat/index.html",
    memory: "pages/memory/index.html",
    music: "pages/music/index.html",
    pet: "pages/pet/index.html",
    moments: "pages/moments/index.html",
    date: "pages/date/index.html",
    settings: "pages/settings/index.html",
  };

  // Public route ids (no auth required)
  const PUBLIC = [];

  // SVG icon set (stroke, no emojis)
  const ICONS = {
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>',
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H8l-4 4V5a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2z"/></svg>',
    memory: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M9 7h6M9 11h6M9 15h4"/></svg>',
    music: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
    pet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="4" r="2"/><circle cx="18" cy="8" r="2"/><circle cx="4" cy="8" r="2"/><circle cx="6" cy="16" r="2"/><circle cx="16" cy="16" r="2"/><path d="M8 14v4a2 2 0 0 0 2 2h0a4 4 0 0 0 4 0h0a2 2 0 0 0 2-2v-4"/></svg>',
    moments: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>',
    date: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
    settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/></svg>',
    brand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5L12 3l9 7.5"/><path d="M5 9.5V20h14V9.5"/><path d="M10 20v-5h4v5"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M8 5v14l11-7z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.6 1.1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>',
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>',
    edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
    logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>',
  };

  function icon(name) { return ICONS[name] || ""; }

  // ---- State ----
  const state = {
    route: "home",
    user: null,
    activeModel: null,
  };

  // ---- Router ----
  function parseHash() {
    const raw = (location.hash || "#/home").replace(/^#\/?/, "");
    const [route, ...rest] = raw.split("/");
    return { route: route || "home", params: rest };
  }

  async function loadPage(route) {
    const file = PAGES[route];
    const view = document.getElementById("app-view");
    if (!file) { location.hash = "/home"; return; }
    try {
      const res = await fetch(file, { cache: "no-cache" });
      if (!res.ok) throw new Error("page not found");
      const html = await res.text();
      view.innerHTML = html;
      highlightNav(route);
      // run page init if defined
      const init = global.LVPages && global.LVPages[route];
      if (typeof init === "function") init(state, route);
      view.scrollTop = 0;
    } catch (e) {
      view.innerHTML = '<section class="card center"><p class="muted">Unable to load page: ' +
        escapeHtml(e.message) + "</p></section>";
    }
  }

  function highlightNav(route) {
    document.querySelectorAll("[data-nav]").forEach(function (el) {
      el.classList.toggle("is-active", el.getAttribute("data-nav") === route);
    });
  }

  function navigate(route) { location.hash = "/" + route; }

  function onHashChange() {
    const { route } = parseHash();
    state.route = route;
    const isPublic = PUBLIC.indexOf(route) !== -1;
    if (!isPublic && !global.LVApi.getToken()) {
      // No token: show login shell inside view (each page handles its own guard)
      // For SPA simplicity, still load the page; pages show login prompt when needed.
    }
    loadPage(route);
  }

  // ---- Shell ----
  function navItem(route, label, iconKey) {
    return '<a class="nav-link" href="#/' + route + '" data-nav="' + route + '">' +
      icon(iconKey) + '<span>' + label + "</span></a>";
  }

  function bottomNavItem(route, label, iconKey) {
    return '<a class="bottom-nav__link" href="#/' + route + '" data-nav="' + route + '" aria-label="' + label + '">' +
      icon(iconKey) + "<span>" + label + "</span></a>";
  }

  function buildShell() {
    const root = document.getElementById("app");
    if (!root) return;
    const desktopNav = [
      navItem("home", "首页", "home"),
      navItem("chat", "对话", "chat"),
      navItem("memory", "记忆", "memory"),
      navItem("music", "音乐", "music"),
      navItem("pet", "AI宠物", "pet"),
      navItem("moments", "朋友圈", "moments"),
      navItem("date", "约会", "date"),
      navItem("settings", "设置", "settings"),
    ].join("");

    const mobileNav = [
      bottomNavItem("home", "首页", "home"),
      bottomNavItem("chat", "对话", "chat"),
      bottomNavItem("memory", "记忆", "memory"),
      bottomNavItem("music", "音乐", "music"),
      bottomNavItem("pet", "宠物", "pet"),
      bottomNavItem("settings", "设置", "settings"),
    ].join("");

    root.innerHTML =
      '<div class="app-layout">' +
        '<aside class="sidebar" aria-label="Primary">' +
          '<div class="sidebar__brand">' +
            '<span class="sidebar__logo">' + icon("brand") + "</span>" +
            "<div><div class=\"sidebar__name\">LandricsVilla</div>" +
            '<div class="sidebar__tag">local-first AI companion</div></div>' +
          "</div>" +
          desktopNav +
          '<div class="divider"></div>' +
          '<button class="nav-link" id="lv-theme-toggle">' + icon("settings") +
          "<span>切换主题</span></button>" +
        "</aside>" +
        '<main class="app-content" id="app-view" tabindex="-1"></main>' +
        '<nav class="bottom-nav" aria-label="Mobile navigation"><ul class="bottom-nav__list">' +
          mobileNav + "</ul></nav>" +
      "</div>";

    const toggle = document.getElementById("lv-theme-toggle");
    if (toggle) toggle.addEventListener("click", toggleTheme);
  }

  // ---- Theme ----
  function getTheme() {
    try { return localStorage.getItem("lv_theme") || "dark"; } catch (e) { return "dark"; }
  }
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("lv_theme", theme); } catch (e) {}
  }
  function toggleTheme() {
    applyTheme(getTheme() === "dark" ? "light" : "dark");
  }

  // ---- Utils exposed globally ----
  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function el(html) {
    const t = document.createElement("template");
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  }
  function toast(msg, kind) {
    let box = document.getElementById("lv-toast");
    if (!box) {
      box = document.createElement("div");
      box.id = "lv-toast";
      box.setAttribute("role", "status");
      box.setAttribute("aria-live", "polite");
      box.style.cssText =
        "position:fixed;bottom:80px;left:50%;transform:translateX(-50%);" +
        "background:var(--surface);color:var(--text);padding:10px 16px;border-radius:12px;" +
        "border:1px solid var(--border);box-shadow:var(--shadow);z-index:200;font-size:14px;";
      document.body.appendChild(box);
    }
    box.textContent = msg;
    box.style.color = kind === "error" ? "var(--danger)" : (kind === "ok" ? "var(--success)" : "var(--text)");
    clearTimeout(box._t);
    box._t = setTimeout(function () { box.textContent = ""; }, 2600);
  }

  // ---- Init ----
  function init() {
    applyTheme(getTheme());
    state.user = global.LVApi.getUser();
    buildShell();
    onHashChange();
    global.addEventListener("hashchange", onHashChange);
  }

  global.LVApp = {
    init: init, navigate: navigate, state: state, icon: icon,
    escapeHtml: escapeHtml, el: el, toast: toast,
    getTheme: getTheme, applyTheme: applyTheme, toggleTheme: toggleTheme,
  };
  global.LVPages = global.LVPages || {};
})(window);
